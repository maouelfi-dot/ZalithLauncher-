package com.movtery.zalithlauncher.ui.fragment

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.view.animation.LayoutAnimationController
import android.widget.EditText
import android.widget.PopupWindow
import android.widget.Toast
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewbinding.ViewBinding
import com.angcyo.tablayout.DslTabLayout
import com.movtery.anim.AnimPlayer
import com.movtery.anim.animations.Animations
import com.movtery.zalithlauncher.R
import com.movtery.zalithlauncher.databinding.FragmentAccountBinding
import com.movtery.zalithlauncher.databinding.ItemOtherServerBinding
import com.movtery.zalithlauncher.databinding.ViewAddOtherServerBinding
import com.movtery.zalithlauncher.databinding.ViewSingleActionPopupBinding
import com.movtery.zalithlauncher.event.single.AccountUpdateEvent
import com.movtery.zalithlauncher.event.value.LocalLoginEvent
import com.movtery.zalithlauncher.event.value.OtherLoginEvent
import com.movtery.zalithlauncher.feature.accounts.AccountUtils
import com.movtery.zalithlauncher.feature.accounts.AccountsManager
import com.movtery.zalithlauncher.feature.accounts.LocalAccountUtils
import com.movtery.zalithlauncher.feature.accounts.LocalAccountUtils.CheckResultListener
import com.movtery.zalithlauncher.feature.accounts.LocalAccountUtils.Companion.checkUsageAllowed
import com.movtery.zalithlauncher.feature.accounts.LocalAccountUtils.Companion.openDialog
import com.movtery.zalithlauncher.feature.accounts.OfflineSkinServer
import com.movtery.zalithlauncher.feature.accounts.SkinPreview
import com.movtery.zalithlauncher.feature.accounts.OtherLoginHelper
import com.movtery.zalithlauncher.feature.log.Logging
import com.movtery.zalithlauncher.feature.login.OtherLoginApi
import com.movtery.zalithlauncher.feature.login.Servers
import com.movtery.zalithlauncher.feature.login.Servers.Server
import com.movtery.zalithlauncher.setting.AllSettings
import com.movtery.zalithlauncher.task.Task
import com.movtery.zalithlauncher.task.TaskExecutors
import com.movtery.zalithlauncher.ui.dialog.EditTextDialog
import com.movtery.zalithlauncher.ui.dialog.OtherLoginDialog
import com.movtery.zalithlauncher.ui.dialog.TipDialog
import com.movtery.zalithlauncher.ui.layout.AnimRelativeLayout
import com.movtery.zalithlauncher.ui.subassembly.account.AccountAdapter
import com.movtery.zalithlauncher.ui.subassembly.account.AccountAdapter.AccountUpdateListener
import com.movtery.zalithlauncher.ui.subassembly.account.AccountViewWrapper
import com.movtery.zalithlauncher.ui.subassembly.account.SelectAccountListener
import com.movtery.zalithlauncher.utils.ZHTools
import com.movtery.zalithlauncher.utils.http.NetworkUtils
import com.movtery.zalithlauncher.utils.path.PathManager
import com.movtery.zalithlauncher.utils.stringutils.StringUtils
import net.kdt.pojavlaunch.Tools
import net.kdt.pojavlaunch.fragments.MicrosoftLoginFragment
import net.kdt.pojavlaunch.value.MinecraftAccount
import org.apache.commons.io.FileUtils
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.json.JSONObject
import java.io.File
import java.util.regex.Pattern


class AccountFragment : FragmentWithAnim(R.layout.fragment_account), View.OnClickListener {
    companion object {
        const val TAG = "AccountFragment"
    }

    private lateinit var binding: FragmentAccountBinding
    private lateinit var mAccountViewWrapper: AccountViewWrapper
    private val mAccountsData: MutableList<MinecraftAccount> = AccountsManager.allAccounts.toMutableList()
    private val mAccountAdapter = AccountAdapter(mAccountsData)

    private val selectAccountListener = object : SelectAccountListener {
        override fun onSelect(account: MinecraftAccount) {
            if (!isTaskRunning()) {
                AccountsManager.currentAccount = account
            } else {
                TaskExecutors.runInUIThread {
                    Toast.makeText(
                        requireActivity(),
                        R.string.tasks_ongoing,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private val mServerActionPopupWindow: PopupWindow = PopupWindow().apply {
        isFocusable = true
        isOutsideTouchable = true
    }

    private val mLocalNamePattern = Pattern.compile("[^a-zA-Z0-9_]")
    private var mOtherServerConfig: Servers? = null
    private val mOtherServerConfigFile = File(PathManager.DIR_GAME_HOME, "servers.json")
    private val mOtherServerList: MutableList<Server> = ArrayList()
    private val mOtherServerViewList: MutableList<View> = ArrayList()

    private lateinit var mProgressDialog: AlertDialog

    /** Offline account that is currently choosing a custom skin */
    private var mSkinTargetAccount: MinecraftAccount? = null
    private val mSkinPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val account = mSkinTargetAccount
        mSkinTargetAccount = null
        if (uri == null || account == null) return@registerForActivityResult
        val ctx = requireContext()
        runCatching {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("cannot read file")
            if (bytes.size > 2 * 1024 * 1024 || !OfflineSkinServer.isValidSkin(bytes)) {
                Toast.makeText(ctx, R.string.account_skin_invalid, Toast.LENGTH_LONG).show()
                return@runCatching
            }
            val target = OfflineSkinServer.skinFileOf(account)
            target.parentFile?.mkdirs()
            target.writeBytes(bytes)
            Toast.makeText(ctx, R.string.account_skin_saved, Toast.LENGTH_LONG).show()
            reloadAccounts()
            showSkinDialog(account)
        }.onFailure { e ->
            Logging.e(TAG, "Failed to import skin: ${e.message}")
            Toast.makeText(ctx, R.string.account_skin_invalid, Toast.LENGTH_LONG).show()
        }
    }

    /** Offline account that is currently choosing a custom cape */
    private var mCapeTargetAccount: MinecraftAccount? = null
    private val mCapePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val account = mCapeTargetAccount
        mCapeTargetAccount = null
        if (uri == null || account == null) return@registerForActivityResult
        val ctx = requireContext()
        runCatching {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("cannot read file")
            if (bytes.size > 2 * 1024 * 1024 || !OfflineSkinServer.isValidCape(bytes)) {
                Toast.makeText(ctx, R.string.account_cape_invalid, Toast.LENGTH_LONG).show()
                return@runCatching
            }
            val target = OfflineSkinServer.capeFileOf(account)
            target.parentFile?.mkdirs()
            target.writeBytes(bytes)
            Toast.makeText(ctx, R.string.account_cape_saved, Toast.LENGTH_LONG).show()
            showSkinDialog(account)
        }.onFailure { e ->
            Logging.e(TAG, "Failed to import cape: ${e.message}")
            Toast.makeText(ctx, R.string.account_cape_invalid, Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Skin dialog for an offline account: choose the arm model (auto / Steve / Alex), pick a PNG file,
     * or remove the custom skin.
     */
    private fun showSkinDialog(account: MinecraftAccount) {
        val ctx = requireContext()
        val models = arrayOf<String?>(null, "classic", "slim")
        val names = arrayOf(
            getString(R.string.account_skin_model_auto),
            getString(R.string.account_skin_model_classic),
            getString(R.string.account_skin_model_slim)
        )
        var selected = models.indexOf(OfflineSkinServer.getModel(account)).coerceAtLeast(0)

        val dp = ctx.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val preview = android.widget.ImageView(ctx).apply {
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            layoutParams = android.widget.LinearLayout.LayoutParams(px(96), px(192)).apply { marginEnd = px(16) }
        }
        val group = android.widget.RadioGroup(ctx).apply {
            orientation = android.widget.RadioGroup.VERTICAL
            names.forEachIndexed { i, n ->
                addView(android.widget.RadioButton(ctx).apply {
                    id = 1000 + i
                    text = n
                    isChecked = i == selected
                    setPadding(px(4), px(10), px(4), px(10))
                })
            }
        }
        var showBack = false
        fun refreshPreview() {
            val bmp = SkinPreview.renderFront(OfflineSkinServer.skinFileOf(account), models[selected] == "slim", 8, showBack, OfflineSkinServer.capeFileOf(account))
            if (bmp != null) preview.setImageBitmap(bmp) else preview.setImageDrawable(null)
        }
        preview.setOnClickListener { showBack = !showBack; refreshPreview() }
        group.setOnCheckedChangeListener { _, checkedId ->
            selected = (checkedId - 1000).coerceIn(0, models.size - 1)
            refreshPreview()
        }
        refreshPreview()
        val capePick = android.widget.Button(ctx).apply { setText(R.string.account_cape_pick) }
        val capeRemove = android.widget.Button(ctx).apply { setText(R.string.account_cape_remove) }
        val hint = android.widget.TextView(ctx).apply {
            setText(R.string.account_skin_preview_hint)
            setPadding(px(4), px(8), px(4), 0)
        }
        val right = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(group)
            addView(capePick)
            addView(capeRemove)
            addView(hint)
        }
        val content = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(px(24), px(12), px(24), px(4))
            addView(preview)
            addView(right)
        }

        val skinDialog = AlertDialog.Builder(ctx)
            .setTitle(R.string.account_change_skin)
            .setView(android.widget.ScrollView(ctx).apply { addView(content) })
            .setPositiveButton(R.string.account_skin_pick_file) { _, _ ->
                OfflineSkinServer.setModel(account, models[selected])
                mSkinTargetAccount = account
                mSkinPicker.launch(arrayOf("image/png"))
            }
            .setNeutralButton(R.string.account_skin_apply_model) { _, _ ->
                OfflineSkinServer.setModel(account, models[selected])
                Toast.makeText(ctx, R.string.account_skin_saved, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.account_skin_remove) { _, _ ->
                OfflineSkinServer.resetSkin(account)
                Toast.makeText(ctx, R.string.account_skin_reset, Toast.LENGTH_SHORT).show()
                reloadAccounts()
            }
            .create()

        capePick.setOnClickListener {
            OfflineSkinServer.setModel(account, models[selected])
            mCapeTargetAccount = account
            skinDialog.dismiss()
            mCapePicker.launch(arrayOf("image/png"))
        }
        capeRemove.setOnClickListener {
            OfflineSkinServer.resetCape(account)
            Toast.makeText(ctx, R.string.account_cape_removed, Toast.LENGTH_SHORT).show()
            refreshPreview()
        }
        skinDialog.show()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentAccountBinding.inflate(layoutInflater)
        mAccountViewWrapper = AccountViewWrapper(binding = binding.viewAccount)
        mProgressDialog = ZHTools.createTaskRunningDialog(binding.root.context)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val context = requireActivity()

        mAccountAdapter.setAccountUpdateListener(object : AccountUpdateListener {
            override fun onViewClick(account: MinecraftAccount) {
                selectAccountListener.onSelect(account)
            }

            override fun onRefresh(account: MinecraftAccount) {
                if (!isTaskRunning()) {
                    if (!NetworkUtils.isNetworkAvailable(context)) {
                        Toast.makeText(context, R.string.account_login_no_network, Toast.LENGTH_SHORT).show()
                        return
                    }
                    AccountsManager.performLogin(context, account)
                } else {
                    Toast.makeText(context, R.string.tasks_ongoing, Toast.LENGTH_SHORT).show()
                }
            }

            override fun onChangeSkin(account: MinecraftAccount) {
                showSkinDialog(account)
            }

            override fun onResetSkin(account: MinecraftAccount) {
                OfflineSkinServer.resetSkin(account)
                Toast.makeText(context, R.string.account_skin_reset, Toast.LENGTH_SHORT).show()
                reloadAccounts()
            }

            override fun onDelete(account: MinecraftAccount) {
                TipDialog.Builder(context)
                    .setTitle(R.string.generic_warning)
                    .setMessage(R.string.account_remove)
                    .setConfirm(R.string.generic_delete)
                    .setWarning()
                    .setConfirmClickListener {
                        val accountFile =
                            File(PathManager.DIR_ACCOUNT_NEW, account.uniqueUUID)
                        val userSkinFile =
                            File(PathManager.DIR_USER_SKIN, account.uniqueUUID + ".png")
                        if (accountFile.exists()) FileUtils.deleteQuietly(accountFile)
                        if (userSkinFile.exists()) FileUtils.deleteQuietly(userSkinFile)
                        File(PathManager.DIR_USER_SKIN, account.uniqueUUID + ".model").takeIf { it.exists() }?.let { FileUtils.deleteQuietly(it) }
                        File(PathManager.DIR_USER_SKIN, account.uniqueUUID + ".cape.png").takeIf { it.exists() }?.let { FileUtils.deleteQuietly(it) }
                        reloadAccounts()
                    }.showDialog()
            }
        })

        binding.apply {
            accountsRecycler.layoutManager = LinearLayoutManager(context)
            accountsRecycler.setLayoutAnimation(
                LayoutAnimationController(
                    AnimationUtils.loadAnimation(
                        context,
                        R.anim.fade_downwards
                    )
                )
            )
            accountsRecycler.adapter = mAccountAdapter

            accountTypeTab.observeIndexChange { _, toIndex, _, fromUser ->
                fun nonMicrosoftLogin(message: Int, login: () -> Unit) {
                    checkUsageAllowed(object : CheckResultListener {
                        override fun onUsageAllowed() {
                            login()
                        }

                        override fun onUsageDenied() {
                            if (!AllSettings.localAccountReminders.getValue()) {
                                login()
                            } else {
                                openDialog(
                                    context,
                                    TipDialog.OnConfirmClickListener { checked ->
                                        LocalAccountUtils.saveReminders(checked)
                                        login()
                                    },
                                    getString(message) + getString(
                                        R.string.account_purchase_minecraft_account_tip
                                    ),
                                    R.string.account_no_microsoft_account_continue
                                )
                            }
                        }
                    })
                }

                if (fromUser) { //需要判断是否为用户手动点击的，否则会一直进入微软登录界面
                    when (toIndex) {
                        //微软账户
                        0 -> ZHTools.swapFragmentWithAnim(
                            this@AccountFragment,
                            MicrosoftLoginFragment::class.java,
                            MicrosoftLoginFragment.TAG,
                            null
                        )
                        //离线账户
                        1 -> {
                            nonMicrosoftLogin(
                                R.string.account_no_microsoft_account_local
                            ) { localLogin() }
                        }
                        //外置账户
                        else -> {
                            nonMicrosoftLogin(
                                R.string.account_no_microsoft_account_other
                            ) { otherLogin(toIndex - 2) /* Server索引需要从0开始 */ }
                        }
                    }
                }
            }

            addServer.setOnClickListener(this@AccountFragment)
            returnButton.setOnClickListener(this@AccountFragment)
        }

        reloadAccounts()
        refreshOtherServer()
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun reloadRecyclerView() {
        this.mAccountsData.clear()
        mAccountsData.addAll(AccountsManager.allAccounts)

        this.mAccountAdapter.notifyDataSetChanged()
        binding.accountsRecycler.scheduleLayoutAnimation()
    }

    private fun reloadAccounts() {
        Task.runTask {
            AccountsManager.reload()
        }.ended(TaskExecutors.getAndroidUI()) {
            reloadRecyclerView()
            mAccountViewWrapper.refreshAccountInfo()
        }.execute()
    }

    private fun SpannableString.spanText(start: Int, end: Int, what: Any) {
        this.setSpan(what, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun localLogin() {
        fun startLogin(name: String) {
            EventBus.getDefault().post(LocalLoginEvent(name.trim()))
        }

        EditTextDialog.Builder(requireActivity())
            .setTitle(R.string.account_login_local_name)
            .setConfirmText(R.string.generic_login)
            .setEmptyErrorText(R.string.account_local_account_empty)
            .setAsRequired()
            .setConfirmListener { editText, _ ->
                val string = editText.text.toString()
                if (string.length <= 2 || string.length > 16 || mLocalNamePattern.matcher(string).find()) {
                    TipDialog.Builder(requireContext())
                        .setTitle(R.string.generic_warning)
                        .setMessage(R.string.account_local_account_invalid)
                        .setWarning()
                        .setTextBeautifier { _, messageText ->
                            val text = messageText.text.toString()
                            val startTag = "[RED;BOLD]"
                            val endTag = "[/RED;BOLD]"

                            val startIndex = text.indexOf(startTag)
                            val endIndex = text.indexOf(endTag)

                            if (startIndex != -1 && endIndex != -1 && endIndex > startIndex) {
                                val styledText = text.substring(startIndex + startTag.length, endIndex)
                                val plainText = text.replace(startTag, "").replace(endTag, "")
                                val adjustedEndIndex = startIndex + styledText.length

                                val spannableString = SpannableString(plainText)
                                spannableString.spanText(startIndex, adjustedEndIndex, ForegroundColorSpan(Color.RED))
                                spannableString.spanText(startIndex, adjustedEndIndex, StyleSpan(Typeface.BOLD))

                                messageText.text = spannableString
                            }
                        }
                        .setCenterMessage(false)
                        .setConfirmClickListener { startLogin(string) }
                        .setCancelable(false)
                        .setConfirmButtonCountdown(3000L)
                        .showDialog()
                } else startLogin(string)

                true
            }.showDialog()
    }

    private fun otherLogin(index: Int) {
        val server = mOtherServerList[index]
        OtherLoginDialog(requireActivity(), server,
            object : OtherLoginHelper.OnLoginListener {
                override fun onLoading() {
                    mProgressDialog.show()
                }

                override fun unLoading() {
                    mProgressDialog.dismiss()
                }

                override fun onSuccess(account: MinecraftAccount) {
                    EventBus.getDefault().post(OtherLoginEvent(account))
                }

                override fun onFailed(error: String) {
                    mProgressDialog.dismiss()

                    TipDialog.Builder(requireActivity())
                        .setTitle(R.string.generic_warning)
                        .setMessage(getString(R.string.other_login_error) + error)
                        .setWarning()
                        .setCancel(android.R.string.copy)
                        .setCancelClickListener {
                            StringUtils.copyText(
                                "error",
                                error,
                                requireActivity()
                            )
                        }
                        .showDialog()
                }
            }).show()
    }

    private fun refreshOtherServer() {
        Task.runTask {
            mOtherServerList.clear()
            if (mOtherServerConfigFile.exists()) {
                runCatching {
                    val serverConfig = Tools.GLOBAL_GSON.fromJson(
                        Tools.read(mOtherServerConfigFile.absolutePath),
                        Servers::class.java
                    )
                    mOtherServerConfig = serverConfig
                    serverConfig.server.forEach { server ->
                        mOtherServerList.add(server)
                    }
                }
            }
        }.ended(TaskExecutors.getAndroidUI()) {
            //将外置服务器添加到账号类别选择栏上
            mOtherServerViewList.forEach { view ->
                binding.accountTypeTab.removeView(view)
            }
            mOtherServerViewList.clear()

            val activity = requireActivity()
            val layoutInflater = activity.layoutInflater

            fun createView(server: Server): AnimRelativeLayout {
                val p8 = Tools.dpToPx(8f).toInt()
                val view = ItemOtherServerBinding.inflate(layoutInflater)
                view.text.text = server.serverName
                view.root.setOnLongClickListener { v ->
                    refreshActionPopupWindow(v, ViewSingleActionPopupBinding.inflate(LayoutInflater.from(activity)).apply {
                        icon.setImageDrawable(
                            ContextCompat.getDrawable(requireActivity(), R.drawable.ic_menu_delete_forever)
                        )
                        text.setText(R.string.generic_delete)
                        text.setOnClickListener {
                            deleteOtherServer(server)
                            mServerActionPopupWindow.dismiss()
                        }
                    })
                    true
                }
                view.root.layoutParams = DslTabLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                return view.root.apply {
                    setPadding(p8, 0, p8, 0)
                }
            }

            mOtherServerList.forEach { server ->
                val view = createView(server)
                mOtherServerViewList.add(view)
                binding.accountTypeTab.addView(view)
            }
        }.execute()
    }

    private fun showServerTypeSelectDialog(stringId: Int, type: Int) {
        EditTextDialog.Builder(requireActivity())
            .setTitle(stringId)
            .setAsRequired()
            .setConfirmListener { editText, _ ->
                addOtherServer(editText, type)
                true
            }.showDialog()
    }

    private fun checkServerConfig() {
        mOtherServerConfig ?: run {
            val servers = Servers()
            servers.server = ArrayList()
            mOtherServerConfig = servers
        }
    }

    private fun addOtherServer(editText: EditText, type: Int) {
        Task.runTask {
            val editString = editText.text.toString()
            val serverUrl =
                if (type == 0) AccountUtils.tryGetFullServerUrl(editString) else editString
            OtherLoginApi.getServeInfo(
                requireActivity(),
                if (type == 0) serverUrl else "https://auth.mc-user.com:233/$serverUrl"
            )?.let { data ->
                val server = Server()
                JSONObject(data).optJSONObject("meta")?.let { meta ->
                    server.serverName = meta.optString("serverName")
                    server.baseUrl = serverUrl
                    if (type == 0) {
                        server.register =
                            meta.optJSONObject("links")?.optString("register") ?: ""
                    } else {
                        server.baseUrl = "https://auth.mc-user.com:233/$serverUrl"
                        server.register = "https://login.mc-user.com:233/$serverUrl"
                    }
                    checkServerConfig()
                    mOtherServerConfig?.server?.apply addServer@{
                        forEach {
                            //确保服务器不重复
                            if (it.baseUrl == server.baseUrl) return@addServer
                        }
                        add(server)
                    }
                    Tools.write(
                        mOtherServerConfigFile.absolutePath,
                        Tools.GLOBAL_GSON.toJson(mOtherServerConfig, Servers::class.java)
                    )
                }
            }
        }.beforeStart(TaskExecutors.getAndroidUI()) {
            mProgressDialog.show()
        }.ended(TaskExecutors.getAndroidUI()) {
            refreshOtherServer()
            mProgressDialog.dismiss()
        }.onThrowable { e ->
            Logging.e("Add Other Server", Tools.printToString(e))
        }.execute()
    }

    private fun deleteOtherServer(server: Server) {
        TipDialog.Builder(requireActivity())
            .setTitle(getString(R.string.account_remove_login_type_title, server.serverName))
            .setMessage(R.string.account_remove_login_type_message)
            .setWarning()
            .setConfirmClickListener {
                checkServerConfig()
                mOtherServerConfig?.server?.remove(server)
                Tools.write(
                    mOtherServerConfigFile.absolutePath,
                    Tools.GLOBAL_GSON.toJson(mOtherServerConfig, Servers::class.java)
                )
                refreshOtherServer()
            }.showDialog()
    }

    private fun refreshActionPopupWindow(anchorView: View, binding: ViewBinding) {
        mServerActionPopupWindow.apply {
            binding.root.measure(0, 0)
            this.contentView = binding.root
            this.width = binding.root.measuredWidth
            this.height = binding.root.measuredHeight
            showAsDropDown(anchorView)
        }
    }

    override fun onStart() {
        super.onStart()
        EventBus.getDefault().register(this)
    }

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun event(event: AccountUpdateEvent) {
        mAccountViewWrapper.refreshAccountInfo()
        reloadRecyclerView()
    }

    override fun onClick(v: View) {
        val activity = requireActivity()
        binding.apply {
            when (v) {
                returnButton -> ZHTools.onBackPressed(activity)
                addServer -> {
                    refreshActionPopupWindow(v, ViewAddOtherServerBinding.inflate(LayoutInflater.from(activity)).apply {
                        val onClickListener = View.OnClickListener { v1 ->
                            when(v1) {
                                addOtherServer -> showServerTypeSelectDialog(R.string.other_login_yggdrasil_api, 0)
                                addUniformPass -> showServerTypeSelectDialog(R.string.other_login_32_bit_server, 1)
                            }
                            mServerActionPopupWindow.dismiss()
                        }
                        addOtherServer.setOnClickListener(onClickListener)
                        addUniformPass.setOnClickListener(onClickListener)
                    })
                }
                else -> {}
            }
        }
    }

    override fun slideIn(animPlayer: AnimPlayer) {
        binding.apply {
            animPlayer.apply(AnimPlayer.Entry(operationLayout, Animations.BounceInLeft))
                .apply(AnimPlayer.Entry(accountTypeLayout, Animations.BounceInDown))
                .apply(AnimPlayer.Entry(accountsRecycler, Animations.BounceInUp))
        }
    }

    override fun slideOut(animPlayer: AnimPlayer) {
        binding.apply {
            animPlayer.apply(AnimPlayer.Entry(operationLayout, Animations.FadeOutRight))
                .apply(AnimPlayer.Entry(accountTypeLayout, Animations.FadeOutUp))
                .apply(AnimPlayer.Entry(accountsRecycler, Animations.FadeOutDown))
        }
    }
}